rsync -avzh --exclude '.git' . serv1:~/PM-GNN-all/
